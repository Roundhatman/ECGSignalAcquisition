﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ChartArea25 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend25 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series25 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea26 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend26 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series26 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea27 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend27 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series27 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Me.chtPlotter = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.chtFourier = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.cmbBaud = New System.Windows.Forms.ComboBox()
        Me.cmbPort = New System.Windows.Forms.ComboBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnSS = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.USART = New System.IO.Ports.SerialPort(Me.components)
        Me.tmrFourier = New System.Windows.Forms.Timer(Me.components)
        Me.tmrPlotter = New System.Windows.Forms.Timer(Me.components)
        Me.chtMovingAverage = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.tmrMvA = New System.Windows.Forms.Timer(Me.components)
        Me.cmbTaps = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblPeak3 = New System.Windows.Forms.Label()
        Me.lblPeak2 = New System.Windows.Forms.Label()
        Me.lblPeak1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblPeakOut3 = New System.Windows.Forms.Label()
        Me.lblPeakOut2 = New System.Windows.Forms.Label()
        Me.lblPeakOut1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        CType(Me.chtPlotter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chtFourier, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chtMovingAverage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'chtPlotter
        '
        ChartArea25.Name = "ChartArea1"
        Me.chtPlotter.ChartAreas.Add(ChartArea25)
        Legend25.Name = "Legend1"
        Me.chtPlotter.Legends.Add(Legend25)
        Me.chtPlotter.Location = New System.Drawing.Point(12, 9)
        Me.chtPlotter.Name = "chtPlotter"
        Series25.ChartArea = "ChartArea1"
        Series25.Legend = "Legend1"
        Series25.Name = "Series1"
        Me.chtPlotter.Series.Add(Series25)
        Me.chtPlotter.Size = New System.Drawing.Size(994, 230)
        Me.chtPlotter.TabIndex = 0
        Me.chtPlotter.Text = "Chart1"
        '
        'chtFourier
        '
        ChartArea26.Name = "ChartArea1"
        Me.chtFourier.ChartAreas.Add(ChartArea26)
        Legend26.Name = "Legend1"
        Me.chtFourier.Legends.Add(Legend26)
        Me.chtFourier.Location = New System.Drawing.Point(12, 245)
        Me.chtFourier.Name = "chtFourier"
        Series26.ChartArea = "ChartArea1"
        Series26.Legend = "Legend1"
        Series26.Name = "Series1"
        Me.chtFourier.Series.Add(Series26)
        Me.chtFourier.Size = New System.Drawing.Size(994, 230)
        Me.chtFourier.TabIndex = 1
        Me.chtFourier.Text = "Chart2"
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(1016, 109)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(201, 23)
        Me.btnStart.TabIndex = 2
        Me.btnStart.Text = "Start"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'cmbBaud
        '
        Me.cmbBaud.ForeColor = System.Drawing.Color.Navy
        Me.cmbBaud.FormattingEnabled = True
        Me.cmbBaud.Items.AddRange(New Object() {"9600", "57600", "115200", "2000000"})
        Me.cmbBaud.Location = New System.Drawing.Point(1094, 9)
        Me.cmbBaud.Name = "cmbBaud"
        Me.cmbBaud.Size = New System.Drawing.Size(123, 27)
        Me.cmbBaud.TabIndex = 3
        Me.cmbBaud.Text = "115200"
        '
        'cmbPort
        '
        Me.cmbPort.ForeColor = System.Drawing.Color.Navy
        Me.cmbPort.FormattingEnabled = True
        Me.cmbPort.Location = New System.Drawing.Point(1094, 43)
        Me.cmbPort.Name = "cmbPort"
        Me.cmbPort.Size = New System.Drawing.Size(123, 27)
        Me.cmbPort.TabIndex = 4
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(1016, 138)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(201, 23)
        Me.btnSave.TabIndex = 5
        Me.btnSave.Text = "Save Data"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnSS
        '
        Me.btnSS.Location = New System.Drawing.Point(1016, 167)
        Me.btnSS.Name = "btnSS"
        Me.btnSS.Size = New System.Drawing.Size(201, 23)
        Me.btnSS.TabIndex = 6
        Me.btnSS.Text = "Screen Shot"
        Me.btnSS.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(1016, 196)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(201, 23)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(1012, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 19)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Baud rate"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(1012, 46)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 19)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "COM Port"
        '
        'USART
        '
        '
        'tmrFourier
        '
        Me.tmrFourier.Enabled = True
        Me.tmrFourier.Interval = 1000
        '
        'tmrPlotter
        '
        Me.tmrPlotter.Enabled = True
        Me.tmrPlotter.Interval = 1
        '
        'chtMovingAverage
        '
        ChartArea27.Name = "ChartArea1"
        Me.chtMovingAverage.ChartAreas.Add(ChartArea27)
        Legend27.Name = "Legend1"
        Me.chtMovingAverage.Legends.Add(Legend27)
        Me.chtMovingAverage.Location = New System.Drawing.Point(12, 481)
        Me.chtMovingAverage.Name = "chtMovingAverage"
        Series27.ChartArea = "ChartArea1"
        Series27.Legend = "Legend1"
        Series27.Name = "Series1"
        Me.chtMovingAverage.Series.Add(Series27)
        Me.chtMovingAverage.Size = New System.Drawing.Size(994, 230)
        Me.chtMovingAverage.TabIndex = 10
        Me.chtMovingAverage.Text = "Chart2"
        '
        'tmrMvA
        '
        Me.tmrMvA.Enabled = True
        Me.tmrMvA.Interval = 1
        '
        'cmbTaps
        '
        Me.cmbTaps.ForeColor = System.Drawing.Color.Navy
        Me.cmbTaps.FormattingEnabled = True
        Me.cmbTaps.Items.AddRange(New Object() {"4", "8", "16", "40", "80", "160"})
        Me.cmbTaps.Location = New System.Drawing.Point(1094, 76)
        Me.cmbTaps.Name = "cmbTaps"
        Me.cmbTaps.Size = New System.Drawing.Size(123, 27)
        Me.cmbTaps.TabIndex = 14
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(1012, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 19)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "M.A.T"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblPeak3)
        Me.GroupBox1.Controls.Add(Me.lblPeak2)
        Me.GroupBox1.Controls.Add(Me.lblPeak1)
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GroupBox1.Location = New System.Drawing.Point(1016, 245)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(201, 86)
        Me.GroupBox1.TabIndex = 16
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Input Signal"
        '
        'lblPeak3
        '
        Me.lblPeak3.AutoSize = True
        Me.lblPeak3.ForeColor = System.Drawing.Color.Navy
        Me.lblPeak3.Location = New System.Drawing.Point(6, 57)
        Me.lblPeak3.Name = "lblPeak3"
        Me.lblPeak3.Size = New System.Drawing.Size(114, 19)
        Me.lblPeak3.TabIndex = 16
        Me.lblPeak3.Text = "Calculating ..."
        '
        'lblPeak2
        '
        Me.lblPeak2.AutoSize = True
        Me.lblPeak2.ForeColor = System.Drawing.Color.Navy
        Me.lblPeak2.Location = New System.Drawing.Point(6, 38)
        Me.lblPeak2.Name = "lblPeak2"
        Me.lblPeak2.Size = New System.Drawing.Size(114, 19)
        Me.lblPeak2.TabIndex = 15
        Me.lblPeak2.Text = "Calculating ..."
        '
        'lblPeak1
        '
        Me.lblPeak1.AutoSize = True
        Me.lblPeak1.ForeColor = System.Drawing.Color.Navy
        Me.lblPeak1.Location = New System.Drawing.Point(6, 19)
        Me.lblPeak1.Name = "lblPeak1"
        Me.lblPeak1.Size = New System.Drawing.Size(114, 19)
        Me.lblPeak1.TabIndex = 14
        Me.lblPeak1.Text = "Calculating ..."
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblPeakOut3)
        Me.GroupBox2.Controls.Add(Me.lblPeakOut2)
        Me.GroupBox2.Controls.Add(Me.lblPeakOut1)
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GroupBox2.Location = New System.Drawing.Point(1016, 337)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(201, 86)
        Me.GroupBox2.TabIndex = 17
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Output Signal"
        '
        'lblPeakOut3
        '
        Me.lblPeakOut3.AutoSize = True
        Me.lblPeakOut3.ForeColor = System.Drawing.Color.Navy
        Me.lblPeakOut3.Location = New System.Drawing.Point(6, 57)
        Me.lblPeakOut3.Name = "lblPeakOut3"
        Me.lblPeakOut3.Size = New System.Drawing.Size(114, 19)
        Me.lblPeakOut3.TabIndex = 16
        Me.lblPeakOut3.Text = "Calculating ..."
        '
        'lblPeakOut2
        '
        Me.lblPeakOut2.AutoSize = True
        Me.lblPeakOut2.ForeColor = System.Drawing.Color.Navy
        Me.lblPeakOut2.Location = New System.Drawing.Point(6, 38)
        Me.lblPeakOut2.Name = "lblPeakOut2"
        Me.lblPeakOut2.Size = New System.Drawing.Size(114, 19)
        Me.lblPeakOut2.TabIndex = 15
        Me.lblPeakOut2.Text = "Calculating ..."
        '
        'lblPeakOut1
        '
        Me.lblPeakOut1.AutoSize = True
        Me.lblPeakOut1.ForeColor = System.Drawing.Color.Navy
        Me.lblPeakOut1.Location = New System.Drawing.Point(6, 19)
        Me.lblPeakOut1.Name = "lblPeakOut1"
        Me.lblPeakOut1.Size = New System.Drawing.Size(114, 19)
        Me.lblPeakOut1.TabIndex = 14
        Me.lblPeakOut1.Text = "Calculating ..."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label4.Location = New System.Drawing.Point(8, -2)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(541, 19)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "EES Data Acquisition & Signal Processing Lab / Lab 4 / L.Swarnajith AS2019494"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1229, 718)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cmbTaps)
        Me.Controls.Add(Me.chtMovingAverage)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSS)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.cmbPort)
        Me.Controls.Add(Me.cmbBaud)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.chtFourier)
        Me.Controls.Add(Me.chtPlotter)
        Me.Font = New System.Drawing.Font("Fira Code", 8.999999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ECG Signal Acquisition"
        CType(Me.chtPlotter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chtFourier, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chtMovingAverage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chtPlotter As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents chtFourier As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents cmbBaud As System.Windows.Forms.ComboBox
    Friend WithEvents cmbPort As System.Windows.Forms.ComboBox
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnSS As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents USART As System.IO.Ports.SerialPort
    Friend WithEvents tmrFourier As System.Windows.Forms.Timer
    Friend WithEvents tmrPlotter As System.Windows.Forms.Timer
    Friend WithEvents chtMovingAverage As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents tmrMvA As System.Windows.Forms.Timer
    Friend WithEvents cmbTaps As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblPeak3 As System.Windows.Forms.Label
    Friend WithEvents lblPeak2 As System.Windows.Forms.Label
    Friend WithEvents lblPeak1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lblPeakOut3 As System.Windows.Forms.Label
    Friend WithEvents lblPeakOut2 As System.Windows.Forms.Label
    Friend WithEvents lblPeakOut1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
