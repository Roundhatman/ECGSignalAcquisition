﻿' EES 208 1.0 Data Acquisition and Signal Processing Lab
' Lab 4.2 Activity 2 & 3
' AS2019494

Imports BasicDSP
Imports System.IO
Imports System.Drawing.Imaging
Imports System.Windows.Forms.DataVisualization.Charting

Public Class frmMain

    Private Const sampleSize As UInt16 = 1000
    Private Const sampleRate As UInt16 = 200
    Private Const defaultPort As String = "COM4"
    Private Const defaultBaud As UInt32 = 115200
    Private Const defaultTaps As Byte = 4
    Private Const savePath As String = "D:\DSP\"

    Private plt As New Series
    Private inFft As New Series
    Private outFft As New Series
    Private movRelative As New Series
    Private movAbsolute As New Series

    Private rxEnabled As Boolean = False
    Private amplitude As String
    Private dataList(sampleSize) As Double
    Private avDataList(sampleSize) As Double
    Private maTaps As Byte = 0
    Private timeStamp As String = Today.Year & "." & Today.Month & "." & Today.Day & "." & Today.Hour & "." & Today.Minute & "." & Today.Second

    Private Structure FourierFrequencyData
        Public peak1 As Double
        Public peak2 As Double
        Public peak3 As Double
        Public max1 As UInt16
        Public max2 As UInt16
    End Structure

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' List down all COM ports
        For Each port As String In Ports.SerialPort.GetPortNames()
            cmbPort.Items.Add(port)
        Next
        cmbPort.Text = defaultPort
        cmbBaud.Text = defaultBaud.ToString
        cmbTaps.Text = defaultTaps

        ' Initialize real-time plotter
        plt.ChartType = SeriesChartType.FastLine
        plt.Color = Color.DodgerBlue
        movRelative.ChartType = SeriesChartType.FastLine
        movRelative.Color = Color.Red
        With chtPlotter.Series
            .Clear()
            .Add(plt)
            .Add(movRelative)
            .Item(0).Name = "Input Signal"
            .Item(1).Name = "Output Signal"
        End With

        ' Initialize frequency graph
        inFft.ChartType = SeriesChartType.FastLine
        inFft.Color = Color.Navy
        outFft.ChartType = SeriesChartType.FastLine
        outFft.Color = Color.Green
        With chtFourier.Series
            .Clear()
            .Add(inFft)
            .Add(outFft)
            .Item(0).Name = "Input Frequency Graph"
            .Item(1).Name = "Output Frequency Graph"
        End With

        ' Initialize filter graph
        movAbsolute.ChartType = SeriesChartType.FastLine
        movAbsolute.Color = Color.DarkGreen
        With chtMovingAverage.Series
            .Clear()
            .Add(movAbsolute)
            .Item(0).Name = "Output Signal"
        End With

    End Sub

    Private Sub USART_DataReceived(sender As Object, e As Ports.SerialDataReceivedEventArgs) Handles USART.DataReceived
        ' Signal acquisition
        amplitude = USART.ReadLine
    End Sub

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click

        On Error GoTo ErrHandler

        If rxEnabled = False Then
            ' Initialize USART
            With USART
                .PortName = cmbPort.Text
                .BaudRate = Convert.ToInt32(cmbBaud.Text)
                .Parity = Ports.Parity.None
                .DataBits = 8
                .StopBits = Ports.StopBits.One
                .RtsEnable = True
            End With

            USART.Open()
            btnStart.Text = "Stop"
            rxEnabled = True

        Else

            USART.Close()
            tmrFourier.Enabled = False
            tmrPlotter.Enabled = False
            tmrMvA.Enabled = False
            btnStart.Text = "Start"
            rxEnabled = False

        End If
        

ErrHandler:
        If Not Err.Number = 0 Then
            MsgBox(Err.Description, MsgBoxStyle.Critical, "Error")
            Resume Next
        End If
    End Sub

    Private Sub tmrFourier_Tick(sender As Object, e As EventArgs) Handles tmrFourier.Tick

        Dim inp As New FourierFrequencyData
        Dim out As FourierFrequencyData

        ' Load input signal data of 1s
        Dim inputSignal As New ComplexWaveform(sampleRate, 1)
        For i As UInt16 = 0 To sampleRate
            inputSignal(i) = dataList(i)
        Next

        ' Load output signal data of 1s
        Dim outputSignal As New ComplexWaveform(sampleRate, 1)
        For i As UInt16 = 0 To sampleRate
            outputSignal(i) = avDataList(i)
        Next

        ' Create frequency spectrum
        Dim inputSpectrum As Spectrum = DFT.ComplexFFT(inputSignal)
        Dim outputSpectrum As Spectrum = DFT.ComplexFFT(outputSignal)

        inFft.Points.Clear()
        outFft.Points.Clear()
        For i As UInt16 = 1 To sampleRate

            ' Plot frequency domain graph
            Dim j As Double = inputSpectrum(i).Mag
            Dim k As Double = outputSpectrum(i).Mag
            inFft.Points.AddXY(i, j)
            outFft.Points.AddXY(i, k)

            ' Input Peak 1
            If j > inp.peak1 AndAlso i > 1 Then
                inp.peak1 = j
                inp.max1 = i
                lblPeak1.Text = "Peak frequency 1 = " & i - 1 & " Hz"
            End If

            ' Input Peak 2
            If j > inp.peak2 AndAlso j < inp.peak1 AndAlso i > 1 Then
                inp.peak2 = j
                inp.max2 = i
                lblPeak2.Text = "Peak frequency 2 = " & i - 1 & " Hz"
            End If

            ' Input Peak 3
            If j > inp.peak3 AndAlso j < inp.peak1 AndAlso j < inp.peak2 AndAlso i > 1 Then
                inp.peak3 = j
                lblPeak3.Text = "Peak frequency 3 = " & i - 1 & " Hz"
            End If

            ' Output Peak 1
            If k > out.peak1 AndAlso i > 1 Then
                out.peak1 = k
                out.max1 = i
                lblPeakOut1.Text = "Peak frequency 1 = " & i - 1 & " Hz"
            End If

            ' Output Peak 2
            If k > out.peak2 AndAlso k < out.peak1 AndAlso i > 1 Then
                out.peak2 = k
                out.max2 = i
                lblPeakOut2.Text = "Peak frequency 2 = " & i - 1 & " Hz"
            End If

            ' Output Peak 3
            If k > out.peak3 AndAlso k < out.peak1 AndAlso k < out.peak2 AndAlso i > 1 Then
                out.peak3 = k
                lblPeakOut3.Text = "Peak frequency 3 = " & i - 1 & " Hz"
            End If

        Next
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Close all handles and end program
        chtPlotter.Series.SuspendUpdates()
        chtFourier.Series.SuspendUpdates()
        chtMovingAverage.Series.SuspendUpdates()
        USART.Close()
        End
    End Sub

    Private Sub tmrPlotter_Tick(sender As Object, e As EventArgs) Handles tmrPlotter.Tick
        On Error Resume Next
        'Application.DoEvents()

        ' Shift data array
        For i As UInt16 = 0 To sampleSize - 1
            dataList(i) = dataList(i + 1)
        Next
        dataList(sampleSize - 1) = Convert.ToDouble(amplitude)

        ' Plot signal
        plt.Points.Clear()
        For i As UInt16 = 0 To sampleSize - 1
            plt.Points.AddXY(i + 1, dataList(i))
        Next

    End Sub

    Private Function movingAverage(samples() As Double, taps As UInt16) As Double
        Dim Avg As Double
        Dim ma As New List(Of Double)

        For i As UInt16 = 0 To samples.Length - 1
            ma.Insert(0, samples(i))
            Avg = 0

            For j As UInt16 = 0 To ma.Count - 1
                Avg += ma(j)
            Next
            Avg = Avg / ma.Count

            If ma.Count = taps Then
                ma.RemoveAt(ma.Count - 1)
            End If

        Next

        Return Avg

    End Function

    Private Sub tmrMvA_Tick(sender As Object, e As EventArgs) Handles tmrMvA.Tick
        On Error Resume Next
        'Application.DoEvents()

        ' Shift data array
        For i As UInt16 = 0 To sampleSize - 1
            avDataList(i) = avDataList(i + 1)
        Next
        avDataList(sampleSize - 1) = movingAverage(dataList, maTaps)

        ' Plot signal
        movRelative.Points.Clear()
        movAbsolute.Points.Clear()
        For i As UInt16 = 0 To sampleSize - 1
            movRelative.Points.AddXY(i + 1, avDataList(i))
            movAbsolute.Points.AddXY(i + 1, avDataList(i))
        Next

    End Sub

    Private Sub cmbTaps_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbTaps.SelectedIndexChanged
        maTaps = Convert.ToByte(cmbTaps.Text)
    End Sub

    Private Sub btnSS_Click(sender As Object, e As EventArgs) Handles btnSS.Click
        On Error GoTo ErrHandler

        chtPlotter.SaveImage(savePath & timeStamp & "_Input.BMP", ImageFormat.Bmp)
        chtFourier.SaveImage(savePath & timeStamp & "_Fourier.BMP", ImageFormat.Bmp)
        chtMovingAverage.SaveImage(savePath & timeStamp & "_Output.BMP", ImageFormat.Bmp)

        MsgBox("Files saved !", MsgBoxStyle.Information, "Done")

ErrHandler:
        If Not Err.Number = 0 Then
            MsgBox(Err.Description, MsgBoxStyle.Critical, "Error")
            Resume Next
        End If

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        On Error GoTo ErrHandler

        Using writer As New StreamWriter(savePath & timeStamp & "_Input.csv")
            writer.WriteLine("index,amplitude")

            For i As UInt16 = 0 To dataList.Length - 1
                writer.WriteLine(i & "," & dataList(i))
            Next

        End Using

        Using writer As New StreamWriter(savePath & timeStamp & "_Output.csv")
            writer.WriteLine("index,amplitude")

            For i As UInt16 = 0 To avDataList.Length - 1
                writer.WriteLine(i & "," & avDataList(i))
            Next

        End Using


        MsgBox("Files saved !", MsgBoxStyle.Information, "Done")

ErrHandler:
        If Not Err.Number = 0 Then
            MsgBox(Err.Description, MsgBoxStyle.Critical, "Error")
            Resume Next
        End If
    End Sub
End Class