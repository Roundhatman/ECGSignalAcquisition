﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GoogleMaps.Samples.samples.Maps.Visualization.Heatmap.Options
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // TODO Uncomment next lines to set same options here in code
            /*
            Heatmap1.Gradient = new List<CssColor>
            {
                new CssColor { Value="rgba(0, 255, 255, 0)" },
                new CssColor { Value="rgba(0, 255, 255, 1)" },
                new CssColor { Value="rgba(0, 191, 255, 1)" },
                new CssColor { Value="rgba(0, 127, 255, 1)" } ,
                new CssColor { Value="rgba(0, 63, 255, 1)" },
                new CssColor { Value="rgba(0, 0, 255, 1)" },
                new CssColor { Value="rgba(0, 0, 223, 1)" },
                new CssColor { Value="rgba(0, 0, 191, 1)" },
                new CssColor { Value="rgba(0, 0, 159, 1)" },
                new CssColor { Value="rgba(0, 0, 127, 1)" },
                new CssColor { Value="rgba(63, 0, 91, 1)" },
                new CssColor { Value="rgba(127, 0, 63, 1)" },
                new CssColor { Value="rgba(191, 0, 31, 1)" },
                new CssColor { Value="rgba(255, 0, 0, 1)" }
            };
            Heatmap1.MaxIntensity = 0.5;
            Heatmap1.Opacity = 0.4;
            Heatmap1.Radius = 25;
            */
        }
    }
}
