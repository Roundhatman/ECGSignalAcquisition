﻿using System.Web.UI;

namespace GoogleMaps.Samples.Markers
{
    public partial class LabeledMarkers : Page
    {
    }
}